package kr.co.hanbit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HanbitApplicationTests {

	@Test
	void contextLoads() {
	}

}
